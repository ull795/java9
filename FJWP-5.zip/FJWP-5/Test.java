package p6;

class Employee
{
	int age = 23;
	String name = "Ullas";
	double salary = 20000;
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Employee();
		System.out.println(e.age);
		System.out.println(e.name);
		System.out.println(e.salary);
	}

}
