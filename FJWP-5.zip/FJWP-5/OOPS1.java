package p6;

public class OOPS1 {

	int age = 26;
	String name = "Ullas";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OOPS1 o = new OOPS1();
		System.out.println(o.age);
		System.out.println(o.name);
		

	}

}
